---
title: Automatización de pruebas con Pyhton
description: Proyecto académico | Automatización de pruebas unitarias y de API usando Python.
slug: automatic-tests-python
date: 2025-05-17 00:00:00+0000
image: pytest.png
categories:
    - DevOps

tags:
    - Python
    - pytest
weight: 1       # You can add weight to some posts to override the default sorting (date descending)
---

Este proyecto fue desarrollado para la asignatura de CI/CD como parte del máster universitario oficial en Desarrollo y Operaciones (DevOps).
El objetivo principal del presente proyecto es llevar a cabo el desarrollo de la automatización de pruebas unitarias y de API de un programa Calculadora dado.
**Repositorio de GitHub:** 
https://github.com/aleingmar/automatic-tests-python


## Memoria del proyecto:
Documentación del proyecto: [**Visualizar documentación en pdf**](/post/automatic-test-python/Act2_AutomatizacionPruebasPython_AlejandroIngles.pdf)

